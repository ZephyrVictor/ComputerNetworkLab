package org.example;

import java.util.List;
import java.util.Map;

public class CacheEntry {
    String filePath;
    String lastModified;
    Map<String, List<String>> responseHeaders;

    public CacheEntry(String filePath, String lastModified, Map<String, List<String>> responseHeaders) {
        this.filePath = filePath;
        this.lastModified = lastModified;
        this.responseHeaders = responseHeaders;
    }
}