package org.example;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.Socket;
import java.net.URL;
import java.sql.SQLOutput;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ClientHandler implements  Runnable{
    private Socket clientSocket; // socket
    // 过滤网站
    private final String forbiddenUrl = "http://today.hit.edu.cn/article/2024/04/02/111785";
    //过滤用户ip
    private String UserIp = "";
    // 跳转前的Url
    private String originUrl = "http://jwts.hit.edu.cn/";
    // 跳转到这个url
    private String targetUrl = "http://today.hit.edu.cn/";

    //缓存
    private static final Map<String, CacheEntry> cache = new ConcurrentHashMap<>();

    public ClientHandler(Socket socket){
        this.clientSocket = socket;
        // 利用Socket直接获取连接的用户ip
        this.UserIp = this.clientSocket.getInetAddress().getHostAddress();
        System.out.println("进程获取到了ip:" + this.UserIp);
    }
    // 覆盖
    @Override
    public void run() {
        // 读取客户端请求
        try{
                // HTTP请求是文本形式的，所以使用字符流来读取它 获取客户端请求的报文
                InputStream clientInput = clientSocket.getInputStream();
                // proxy服务器一通操作之后，将response返回给客户
                OutputStream clientOutput = clientSocket.getOutputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(clientInput));
                // 读取请求  读一行 这个方法还挺方便的
                String requestLine = reader.readLine();
                // 请求为空 直接返回
                if(requestLine == null){
                    return;
                }
                System.out.println("收到了一个请求:" + requestLine);
                //对请求进行分割
                String[] tokens = requestLine.split(" ");
                //拿到method和url
                String method = tokens[0];
                String urlStr = tokens[1];

                //用户IP过滤
                if(clientSocket.getInetAddress().getHostAddress().equals(this.UserIp)){
                    System.out.println("哈哈哈，你被拦截了，你的ip是"+this.UserIp+" 拦截，爽！");
                    // 返回403
                    clientOutput.write("HTTP/1.1 403 Forbidden\r\n\r\n".getBytes());
                    return;
                }

                // 网站过滤
                if (urlStr.contains(this.forbiddenUrl)) {
                    System.out.println("这个网站你不许上， 拦截，爽！");
                    clientOutput.write("HTTP/1.1 403 Forbidden\r\n\r\n".getBytes());
                    return;
                }

                // 网站引导
                if (urlStr.contains(this.originUrl)) {
                    urlStr = urlStr.replace(this.originUrl, this.targetUrl);
                    System.out.println("引导至: " + urlStr);
//                    System.out.println("哈哈哈哈，想跑，门都没有，直接给你拽回来");
                }

                handleRequest(method, urlStr, clientOutput);
        } catch (IOException e) {
                e.printStackTrace();
        } finally {
            try{
                clientSocket.close();
                System.out.println("Socket已经关闭，连接关闭");
            } catch (IOException e){
                // 忽略了
            }
        }

        }
    private void handleRequest(String method, String urlStr, OutputStream clientOutput) throws IOException {
        if (!"GET".equals(method)) {
            String errMsg = "HTTP/1.1 405 Method Not Allowed\r\n\r\n";
            clientOutput.write(errMsg.getBytes());
            return;
        }

        URL url = new URL(urlStr);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();

        CacheEntry cacheEntry = cache.get(urlStr);
        if (cacheEntry != null && new File(cacheEntry.filePath).exists()) {
            connection.setRequestProperty("If-Modified-Since", cacheEntry.lastModified);
            int statusCode = connection.getResponseCode();
            if (statusCode == HttpURLConnection.HTTP_NOT_MODIFIED) {
                System.out.println("缓存命中了:" + urlStr + "缓存，爽！");
                sendFileAndHeadersToClient(cacheEntry.filePath, cacheEntry.responseHeaders, clientOutput);
                System.out.println("缓存命中了:" + urlStr + "缓存，爽！");
            } else {
                System.out.println(urlStr + "的内容已更新，重新缓存");
                cacheAndSendResponse(connection, urlStr, clientOutput);
            }
        } else {
            System.out.println(urlStr + "未缓存，现在缓存，爽！");
            cacheAndSendResponse(connection, urlStr, clientOutput);
        }
    }

    private void cacheAndSendResponse(HttpURLConnection connection, String urlStr, OutputStream clientOutput) throws IOException {
        int statusCode = connection.getResponseCode();
        if (statusCode >= HttpURLConnection.HTTP_OK && statusCode < HttpURLConnection.HTTP_MULT_CHOICE) {
            String lastModified = connection.getHeaderField("Last-Modified");
            Map<String, List<String>> responseHeaders = connection.getHeaderFields();
            String filePath = saveResponseToFile(connection.getInputStream());
            cache.put(urlStr, new CacheEntry(filePath, lastModified, responseHeaders));
            sendFileAndHeadersToClient(filePath, responseHeaders, clientOutput);
        } else {
            String errMsg = "HTTP/1.1 " + statusCode + " " + connection.getResponseMessage() + "\r\n\r\n";
            clientOutput.write(errMsg.getBytes());
        }
    }

    private void sendFileAndHeadersToClient(String filePath, Map<String, List<String>> responseHeaders, OutputStream clientOutput) throws IOException {
        if (responseHeaders.get(null) != null) {
            String statusLine = responseHeaders.get(null).get(0) + "\r\n";
            clientOutput.write(statusLine.getBytes());
        }
        for (Map.Entry<String, List<String>> entry : responseHeaders.entrySet()) {
            if (entry.getKey() != null) {
                for (String value : entry.getValue()) {
                    clientOutput.write((entry.getKey() + ": " + value + "\r\n").getBytes());
                }
            }
        }
        clientOutput.write("\r\n".getBytes());

        try (FileInputStream fis = new FileInputStream(new File(filePath))) {
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) != -1) {
                clientOutput.write(buffer, 0, bytesRead);
            }
        }
        clientOutput.flush();
    }

    private String saveResponseToFile(InputStream inputStream) throws IOException {
        File cacheDir = new File("cache");
        if (!cacheDir.exists()) {
            cacheDir.mkdirs();
        }
        File tempFile = File.createTempFile("cache", ".tmp", cacheDir);
        try (FileOutputStream fos = new FileOutputStream(tempFile)) {
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                fos.write(buffer, 0, bytesRead);
            }
        }
        return tempFile.getAbsolutePath();
    }
}
