package org.example;

import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class HttpProxyServer {
    public static void main(String[] args) {
        int port = 1234; // 代理端口
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("HTTP Proxy Server started on port " + port);
            ExecutorService executor = Executors.newCachedThreadPool();

            while (true) {
                Socket clientSocket = serverSocket.accept();
                executor.submit(new ClientHandler(clientSocket));
            }
        } catch (IOException e) {
            System.err.println("Server Exception: " + e.getMessage());
        }
    }
}